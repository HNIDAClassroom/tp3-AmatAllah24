package ma.ac.esi.referentielCompetences.controleur;
import Model.ConnectBd;
import Model.User;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/connectBd")
public class test extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ConnectBd connectBd;

    public test() {
        super();
        connectBd = new ConnectBd(); 
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("uname");
        String password = request.getParameter("psw");

        System.out.println("Formulaire soumis avec login = " + login + ", password = " + password);

        if (login != null && password != null) {
            System.out.println("Paramètres non nuls. Appel de connectBd.findUser...");
            System.out.println("Login: " + login);
            System.out.println("Password: " + password);

            User user = connectBd.FindUser(login, password);

            System.out.println("Méthode connectBd.findUser appelée.");

            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();

            if (user != null) {
                System.out.println("Utilisateur trouvé. Affichage de la page de bienvenue...");

                out.println("<html>");
                out.println("<head>");
                out.println("<title>Bienvenue</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Bienvenue, " + user.getLogin() + " !</h2>");
                out.println("</body>");
                out.println("</html>");
            } else {
                System.out.println("Utilisateur non trouvé. Affichage de la page d'échec d'authentification...");

                out.println("<html>");
                out.println("<head>");
                out.println("<title>Échec d'authentification</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Échec de l'authentification. Vérifiez vos informations de connexion.</h2>");
                out.println("</body>");
                out.println("</html>");
            }
        } else {
            System.out.println("Paramètres login et password nuls. Affichage du message d'erreur.");

            response.getWriter().println("Les paramètres login et password ne doivent pas être nuls.");
        }
        /*if (login != null && password != null) {
            System.out.println("Paramètres non nuls. Appel de connectBd.addUser...");
            System.out.println("Login: " + login);
            System.out.println("Password: " + password);

            // Ajouter l'utilisateur à la base de données
            connectBd.addUser(login, password);

            System.out.println("Méthode connectBd.addUser appelée.");

            // Rediriger vers une page de confirmation ou effectuer toute autre action nécessaire
        } else {
            System.out.println("Paramètres login et password nuls. Affichage du message d'erreur.");

            // Gérer le cas où les paramètres sont nuls
        }*/
    }
    
}


